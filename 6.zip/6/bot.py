
import asyncio
import random

from aiogram import Bot, Dispatcher
from aiogram.types import Message
from aiogram.filters import Command

TOKEN = "ВАШ ТОКЕН"

bot = Bot(token=TOKEN)
dp = Dispatcher()


# Запуск бота
@dp.message(Command("start"))
async def start(message: Message):
    await message.answer(
        "Бот работает!\n\n"
        "1. Отправь число, чтобы получить его квадрат.\n"
        "2. Отправь слово, чтобы получить его заглавными буквами.\n"
        "3. Напиши: Имя Азиз.\n"
        "4. Напиши /удача, чтобы испытать удачу."
    )


# Задание 1. Число в квадрате
@dp.message(lambda message: message.text and message.text.isdigit())
async def square(message: Message):
    number = int(message.text)
    result = number ** 2
    await message.answer(f"Квадрат числа {number} = {result}")


# Задание 2. Слово в верхнем регистре
@dp.message(lambda message: message.text and message.text.isalpha())
async def uppercase(message: Message):
    await message.answer(message.text.upper())


# Задание 3. Имя пользователя
@dp.message(lambda message: message.text and message.text.startswith("Имя "))
async def name_handler(message: Message):
    name = message.text[4:].strip()
    await message.answer(f"Тебя зовут {name}")


# Задание 4. Удача
@dp.message(Command("удача"))
async def luck(message: Message):
    number = random.randint(1, 12)

    await message.answer(f"Тебе выпало число: {number}")

    if number in (3, 9, 12):
        await message.answer("Победитель!")
    else:
        await message.answer("Попытайся еще раз")


# Запуск программы
async def main():
    await bot.delete_webhook(drop_pending_updates=True)
    print("Бот успешно запущен!")
    await dp.start_polling(bot)


if __name__ == "__main__":
    asyncio.run(main())
